from django.apps import AppConfig


class ProveedoresConfig(AppConfig):
    name = 'proveedores'
