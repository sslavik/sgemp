class Cliente:
    def __init__(self, nombre, apellido, edad, departamento):
        self.nombre = nombre
        self.apellido = apellido
        self.edad = edad
        self.departamento = departamento
